#include <geoc/geometry/Triangulation.h>
#include <geoc/geometry/Triangle.h>
#include <geoc/geometry/Circle.h>
#include <geoc/math/Math.h>
#include <geoc/scene/LineSegmentEnt.h>
#include <geoc/scene/TriangleEnt.h>
#include <geoc/GeocException.h>
#include <algorithm>
#include <sstream>
#include <cstdio>

using namespace geoc;
using namespace std;





Triangulation::Triangulation() {
}

Triangulation::~Triangulation() {
}

struct Vertice;
struct Face;
struct Edge
{
	Vertice *vertice;
	Face *face;
	Edge *next;
	Edge *reverse;
};


struct Vertice
{
	double x;
	double y;
	Edge *edge;
};


struct Face
{
	Edge *edge;
};



void getVerticesOfFace(Vector3 &vA, Vector3 &vB, Vector3 &vC, Face &face) {
	//cout << "1" << endl;
	double ax, ay, bx, by, cx, cy, zero;
	//cout << "10" << endl;
	ax = face.edge->vertice->x;
	ay = face.edge->vertice->y;

	//cout << "100" << endl;
	bx = face.edge->next->vertice->x;
	by = face.edge->next->vertice->y;
	//cout << "1000" << endl;
	cx = face.edge->next->next->vertice->x;
	cy = face.edge->next->next->vertice->y;
	//cout << "10000" << endl;
	zero = 0;

	vA = Vector3(ax, ay, zero);
	vB = Vector3(bx, by, zero);
	vC = Vector3(cx, cy, zero);
	//cout << "1001" << endl;
}



bool dentroPuntoEnFace(Vector3 &vA, Vector3 &vB, Vector3 &vC, const Vector3 &p) {

	//Orientation
	//cout << "Orientation" << endl;
	//cout << "va : " << vA << "vb : " << vB << "vC : " << vC << endl;
	num orientation = Math::orientation2D(vA, vB, vC);
	////cout << endl << "t[0]: " << t[0] << " t[01]: " << t[1] << " t[2]: " << t[2] << " p: " << p << endl;
	//Orientation Triangles a b c
	num a = Math::orientation2D(vA, vB, p);
	num b = Math::orientation2D(vB, vC, p);
	num c = Math::orientation2D(vC, vA, p);
	//cout << endl << "o: " << orientation << " a: " << a << " b: " << b << " c: " << c << endl;
	if(a == orientation and  b == orientation and c == orientation) {
		return true;
	}else if(a == 0 and  b == orientation and c == orientation) {
		return true;
	}else if(a == orientation and  b == 0 and c == orientation) {
		return true;;
	}else if(a == orientation and  b == orientation and c == 0) {
		return true;
	}else if(a == 0 and  b == 0 and c == orientation) {
		return true;
	}else if(a == orientation and  b == 0 and c == 0) {
		return true;
	}else if(a == 0 and  b == orientation and c == 0) {
		return true;
	}
	//cout << "OOOOOOOOOOOOOOO" << endl;
	return false;
}


bool dentroPuntoAuxEnFace(Vector3 &vA, Vector3 &vB, Vector3 &vC, Vector3 &p) {

	//Orientation
	num orientation = Math::orientation2D(vA, vB, vC);
	////cout << endl << "t[0]: " << t[0] << " t[01]: " << t[1] << " t[2]: " << t[2] << " p: " << p << endl;
	//Orientation Triangles a b c
	num a = Math::orientation2D(vA, vB, p);
	num b = Math::orientation2D(vB, vC, p);
	num c = Math::orientation2D(vC, vA, p);
	////cout << endl << "o: " << orientation << " a: " << a << " b: " << b << " c: " << c << endl;
	if(a == orientation and  b == orientation and c == orientation) {
		return true;
	}else if(a == 0 and  b == orientation and c == orientation) {
		return true;
	}else if(a == orientation and  b == 0 and c == orientation) {
		return true;;
	}else if(a == orientation and  b == orientation and c == 0) {
		return true;
	}else if(a == 0 and  b == 0 and c == orientation) {
		return true;
	}else if(a == orientation and  b == 0 and c == 0) {
		return true;
	}else if(a == 0 and  b == orientation and c == 0) {
		return true;
	}

	return false;
}

void insertPointEnFace(Vector3 &vA, Vector3 &vB, Vector3 &vC, Face &face, const Vector3 &p, Vector3 &paux) {


	cout << "INSERT" << endl;
	//cout << endl << endl << "GENERO EL NUEVO PUNTO" << endl;
	bool isPauxInside = dentroPuntoAuxEnFace(vA, vB, vC, paux);




	
	

	//cout  << "INICIALIZO" << endl;

	Edge *ea = face.edge;
	//cout << "OK A" << endl;
	Edge *eb = face.edge->next;

	//cout << "OK B" << endl;
	Edge *ec = face.edge->next->next;

	//cout << "OK C" << endl;
	Vertice vpvalor;
	vpvalor.x = p[0];
	vpvalor.y = p[1];
	
	//cout << "OK PV" << endl;


	Face *faceA = new Face;
	Face *faceB = new Face;
	Face *faceC = new Face;


	Vertice *vp = new Vertice;
	//cout << "OK faces" << endl;

	Edge *ebp = new Edge;
	//cout << "OK E1" << endl;
	Edge *ebpr = new Edge;
	//cout << "OK E2" << endl;
	Edge *ecp = new Edge;
	//cout << "OK E3" << endl;
	Edge *ecpr = new Edge;
	//cout << "OK E4" << endl;
	Edge *epa = new Edge;
	//cout << "OK E5" << endl;
	Edge *epar = new Edge;

	//cout  << "INICIALIZO FIN" << endl;


	
	faceA->edge = ea;

	ea->face = faceA;
	ea->next = ebp;

	ebp->face = faceA;
	ebp->vertice = eb->vertice;
	ebp->next = epa;
	ebp->reverse = ebpr;

	epa->vertice = vp;
	vp->edge = epa;

	epa->face = faceA;
	epa->next = ea;
	epa->reverse = epar;
	//cout  << "CARA-A" << endl;
	faceB->edge = eb;

	eb->face = faceB;
	eb->next = ecp;

	ebpr->vertice = vp;
	ebpr->face = faceB;
	ebpr->next = eb;
	ebpr->reverse = ebp;

	ecp->vertice = ec->vertice;
	ecp->face = faceB;
	ecp->next = ebpr;
	ecp->reverse = ecpr;
	//cout  << "CARA-B" << endl;

	faceC->edge = ec;

	ec->face = faceC;
	ec->next = epar;

	epar->vertice = ea->vertice;
	epar->face = faceC;
	epar->next = ecpr;
	epar->reverse = epa;

	ecpr->vertice = vp;
	ecpr->face = faceC;
	ecpr->next = ec;
	ecpr->reverse =ecp;
	//cout  << "CARA-C" << endl;
	if (isPauxInside)
	{
		//cout  << "AUX ENLA CARA" << endl;
		double x, y, z;
		x = p[0];
		y = p[1];
		z = 0;
		Vector3 *pointV = new Vector3(x, y, z);

		if(dentroPuntoAuxEnFace(vA, vB, *pointV, paux)){ 
			face.edge = NULL;
			face = *faceA; 
			//cout  << "Nueva Cara A" << endl;
		}
		else if(dentroPuntoAuxEnFace(vB, vC, *pointV, paux)){
			face.edge = NULL; 
			face = *faceB;
			//cout  << "Nueva Cara B" << endl;
		}
		else if(dentroPuntoAuxEnFace(vC, vA, *pointV, paux)){ 
			face.edge = NULL; 
			face = *faceC; 
			//cout  << "Nueva Cara C" << endl;
		}
	}
	//cout << "FIN INSERTAR PUNTO" << endl;
}


bool nextFace(Vector3 &v, Vector3 &w, const Vector3 &p, Vector3 &paux) {
	num a = Math::orientation2D(v, w, p);
	num b = Math::orientation2D(v, w, paux);
	num c = Math::orientation2D(paux, p, v);
	num d = Math::orientation2D(paux, p, w);

	if(a!=b and c!=d) return true;
	return false;
}

void generateTriangulation(Face &face, const Vector3 &p, Vector3 &paux) {
	Vector3 vA;
	Vector3 vB;
	Vector3 vC;

	getVerticesOfFace(vA, vB, vC, face);
	//cout << "GENERANDO" << endl;
	if(dentroPuntoEnFace(vA, vB, vC, p) == true) {
		//cout << "INSTERTO" << endl;
		insertPointEnFace(vA, vB, vC, face, p, paux);

	}else if(nextFace(vA, vB, p, paux) == true) {
		//cout << "NA" << endl;
		generateTriangulation(*(face.edge->reverse->face), p, paux);

	}else if(nextFace(vB, vC, p, paux) == true) {
		//cout << "NB" << endl;
		generateTriangulation(*(face.edge->next->reverse->face), p, paux);

	}else if(nextFace(vC, vA, p, paux) == true) {
		//cout << "NC" << endl;
		generateTriangulation(*(face.edge->next->next->reverse->face), p, paux);
	}


}

void pintar(Face &face, std::vector<LineSegmentEnt>& segments) {

/*

	LineSegment * lin = new LineSegment(face.edge->x, face.edge->y);
	LineSegmentEnt * lins = new LineSegmentEnt(*lin);
	segments.push_back(*lins);
	LineSegment * lin2 = new LineSegment(face.edge->next->x, face.edge->next->y);
	LineSegmentEnt * lins2 = new LineSegmentEnt(*lin);
	segments.push_back(*lins2);
	LineSegment * lin3 = new LineSegment(face.edge->next->next->x, face.edge->next->next->y);
	LineSegmentEnt * lins3 = new LineSegmentEnt(*lin);
	segments.push_back(*lins3);
	if (face->edge->reverse != NULL)
	{
		Face *f = new Face();
		f = face->edge->reverse;
		face->edge = NULL;
		pintar(f,segments);
	}*/
}


void Triangulation::triangulate(const std::vector<Vector3>& ps,
                                const std::vector<int>& idxs,
                                std::vector<LineSegmentEnt>& segments,
                                std::vector<TriangleEnt>& triangles,
                                std::vector<TriangleEnt>& triangles_pruned) {
	printf("Compiling student triangulation\n");

//// ---- Triangulo y Punto Auxiliar ---- ////
//

	double maxX = ps[0][0];
	double minX = ps[0][0];
	double maxY = ps[0][1];
	double minY = ps[0][1];

	double size =  ps.size();
	double pointX = 0;
	double pointY = 0;

	for (int i = 0; i < ps.size(); ++i) {

		pointX =  pointX + ps[i][0];
		pointY =  pointY + ps[i][1];

		if(maxX < ps[i][0]) maxX = ps[i][0];
		if(minX > ps[i][0]) minX = ps[i][0];
		if(maxY < ps[i][1]) maxY = ps[i][1];
		if(minY > ps[i][1]) minY = ps[i][1];
	
		////cout << "Max " << maxX << " : " << maxY<< endl;
		////cout << "Min " << minX << " : " << minY << endl<< endl<< endl; 
	}
	pointX = pointX/size;
	pointY = pointY/size;
	//cout << "Max " << maxX << " : " << maxY<< endl;
	//cout << "Min " << minX << " : " << minY << endl<< endl<< endl; 

	//Points of Big Triangle
	double tAx, tBx, tCx, tAy, tBy, tCy, zero;

	zero = 0;
	tAx = minX - abs((maxY-minY));
	tAy = minY - 1000;
	tCx = maxX + abs((maxY-minY));
	tCy = minY - 1000;

	tBx = minX + abs((maxX - minX)/2);
	tBy = maxY + abs(maxX - minX);

	Vector3 *tA = new Vector3(tAx, tAy, zero);
	Vector3 *tB = new Vector3(tBx, tBy, zero);
	Vector3 *tC = new Vector3(tCx, tCy, zero);

	LineSegment *AB = new LineSegment(*tA, *tB);
	LineSegment * BC = new LineSegment(*tB, *tC);
	LineSegment * CA = new LineSegment(*tC, *tA);

	LineSegmentEnt * ABent = new LineSegmentEnt(*AB);
	LineSegmentEnt * BCent = new LineSegmentEnt(*BC);
	LineSegmentEnt * CAent = new LineSegmentEnt(*CA);

	segments.push_back(*ABent);
	segments.push_back(*BCent);
	segments.push_back(*CAent);

	double medianY = minY + abs((maxY - minY)/2);
	//Vector3 * point = new Vector3(tBx, medianY, zero);
	Vector3 * pointAux = new Vector3(pointX, pointY, zero);


	LineSegment *pointToB = new LineSegment(*pointAux, *tB);
	LineSegmentEnt * pointToBent = new LineSegmentEnt(*pointToB);
	segments.push_back(*pointToBent);

//
////////////////////////////////////////////////////



	Vertice verticeA;
	Vertice verticeB;
	Vertice verticeC;
	Face *face = new Face;
	Edge *edgeA  = new Edge;
	Edge *edgeB  = new Edge;
	Edge *edgeC  = new Edge;
	Edge *edgeAr  = new Edge;
	Edge *edgeBr  = new Edge;
	Edge *edgeCr  = new Edge;

	face->edge = edgeA;
	verticeA.x = tAx;
	verticeA.y = tAy;
	verticeB.x = tBx;
	verticeB.y = tBy;
	verticeC.x = tCx;
	verticeC.y = tCy;
	verticeA.edge = edgeA;
	verticeB.edge = edgeB;
	verticeC.edge = edgeC;

	edgeA->vertice = &verticeA;
	edgeA->face = face;
	edgeA->next = edgeB;
	edgeA->reverse = NULL;

	edgeB->vertice = &verticeB;
	edgeB->face = face;
	edgeB->next = edgeC;
	edgeB->reverse = NULL;

	edgeC->vertice = &verticeC;
	edgeC->face = face;
	edgeC->next = edgeA;
	edgeC->reverse = NULL;


	//cout << "va : " << verticeA.x << ", " << verticeA.y << " vb : " << verticeB.x << ", " << verticeB.y << " vC : " << verticeC.x << ", " << verticeC.y << endl;

	for (int i = 0; i < ps.size(); ++i)
	{

		generateTriangulation(*face, ps[i], *pointAux);
		
	}



	pintar(*face, segments);

////////////////////////////////////////////////////////////
	for (int i = 0; i < (ps.size()-3); ++i)
	{
		LineSegment * lin = new LineSegment(ps[i], ps[i+1]);
		LineSegmentEnt * lins = new LineSegmentEnt(*lin);
		segments.push_back(*lins);


		/*Vector3 new_point = ps[i];
		Vector3 new_point2 = ps[i+1];
		Vector3 new_point3 = ps[i+2];

		TriangleEnt tb = TriangleEnt(new_point, new_point2, new_point3);
		triangles.push_back(tb);*/

	}
	// Add code here.
}

