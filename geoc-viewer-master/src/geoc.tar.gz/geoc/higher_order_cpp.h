#ifndef _GEOC_HIGHER_ORDER_CPP
#define _GEOC_HIGHER_ORDER_CPP

#include <geoc/algorithms.h>
#include <boost/function.hpp>
#include <boost/lambda/lambda.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/bind.hpp>

#endif  //_GEOC_HIGHER_ORDER_CPP
