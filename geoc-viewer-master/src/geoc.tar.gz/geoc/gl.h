#ifndef _GEOC_GL_H
#define _GEOC_GL_H

#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#endif
#include <GL/gl.h>

#endif  //_GEOC_GL_H
