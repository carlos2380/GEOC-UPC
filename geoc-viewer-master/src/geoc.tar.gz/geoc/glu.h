#ifndef _GEOC_GLU_H
#define _GEOC_GLU_H

#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#endif
#include <GL/glu.h>

#endif  //_GEOC_GLU_H
